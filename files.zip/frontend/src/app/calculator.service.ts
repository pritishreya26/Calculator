import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

interface CalcReq { a: number; b: number; operation: string; }
interface CalcResp { success: boolean; result?: number; error?: string; }

@Injectable({ providedIn: 'root' })
export class CalculatorService {
  private baseUrl = '/api/calculator'; // use proxy or CORS

  constructor(private http: HttpClient) { }

  calculate(a: number, b: number, operation: string): Observable<CalcResp> {
    const body: CalcReq = { a, b, operation };
    return this.http.post<CalcResp>(this.baseUrl, body);
  }
}