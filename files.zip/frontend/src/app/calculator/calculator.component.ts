import { Component } from '@angular/core';
import { CalculatorService } from '../calculator.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent {
  a = 0;
  b = 0;
  operation = 'add';
  result: number | null = null;
  error: string | null = null;
  loading = false;

  constructor(private calcSvc: CalculatorService) { }

  onCalculate() {
    this.loading = true;
    this.result = null;
    this.error = null;

    this.calcSvc.calculate(this.a, this.b, this.operation).subscribe({
      next: res => {
        this.loading = false;
        if (res.success) {
          this.result = res.result ?? null;
        } else {
          this.error = res.error ?? 'Unknown error';
        }
      },
      error: err => {
        this.loading = false;
        this.error = err?.error?.error ?? err.message ?? 'Request failed';
      }
    });
  }
}