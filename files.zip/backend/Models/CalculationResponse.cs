namespace CalculatorApi.Models
{
    public class CalculationResponse
    {
        public bool Success { get; set; }
        public double? Result { get; set; }
        public string? Error { get; set; }
    }
}