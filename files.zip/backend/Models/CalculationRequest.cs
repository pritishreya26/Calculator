namespace CalculatorApi.Models
{
    public class CalculationRequest
    {
        public double A { get; set; }
        public double B { get; set; }
        // operation: "add", "sub", "mul", "div"
        public string Operation { get; set; } = "add";
    }
}