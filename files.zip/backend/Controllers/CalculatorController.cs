using Microsoft.AspNetCore.Mvc;
using CalculatorApi.Models;

namespace CalculatorApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CalculatorController : ControllerBase
{
    [HttpPost]
    public ActionResult<CalculationResponse> Calculate([FromBody] CalculationRequest req)
    {
        try
        {
            double r = req.Operation.ToLower() switch
            {
                "add" or "+" => req.A + req.B,
                "sub" or "-" => req.A - req.B,
                "mul" or "*" or "x" => req.A * req.B,
                "div" or "/" => req.B == 0 ? throw new DivideByZeroException() : req.A / req.B,
                _ => throw new InvalidOperationException($"Unsupported operation '{req.Operation}'")
            };

            return Ok(new CalculationResponse { Success = true, Result = r });
        }
        catch (DivideByZeroException)
        {
            return BadRequest(new CalculationResponse { Success = false, Error = "Division by zero" });
        }
        catch (Exception ex)
        {
            return BadRequest(new CalculationResponse { Success = false, Error = ex.Message });
        }
    }
}