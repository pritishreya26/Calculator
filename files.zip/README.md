# CalculatorFullStack

## Prereqs
- .NET 8 SDK
- Node 18+, npm
- Angular CLI (optional: npx @angular/cli)

## Run backend
cd backend
dotnet run --urls "http://localhost:5000"

## Run frontend (dev)
cd frontend
npm install
ng serve --proxy-config proxy.conf.json
# or without proxy: ng serve and rely on CORS

Open http://localhost:4200 and use the calculator.

## Docker (optional)
You can create Dockerfiles for each service and a docker-compose.yml to run both.